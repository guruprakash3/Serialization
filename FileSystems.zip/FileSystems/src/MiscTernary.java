public class MiscTernary
{
    public static void main(String[] args)
    {		
        int n = 16;
        boolean flag = (n % 2 == 0 ? true : false ); 
        System.out.println(n + " is even? " + flag);
    }
}
 