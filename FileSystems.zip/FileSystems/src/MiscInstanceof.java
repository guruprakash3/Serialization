class Institute
{
  public Institute() {}
  public void myInstitute()
  {
    System.out.println("This is our Institute");
  }
}
 
public class MiscInstanceof
{
  public static void main(String[] args)
  {
    Institute newInstitute = new Institute();
    newInstitute.myInstitute();
    System.out.println("Here we can gain the Knowledge " + (newInstitute instanceof Institute));
    System.out.println("Spread the Knowledge " + (newInstitute instanceof Object));
  }
}