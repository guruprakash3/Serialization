import java.io.FileOutputStream;  
public class FileOp1
{  
    public static void main(String args[])
    {    
           try
           {    
             FileOutputStream fout=new FileOutputStream("fileName1.txt");    
             fout.write(65);    
             fout.close();    
             System.out.println("success");    
            }
           catch(Exception e){System.out.println(e);
            }    
      }    
}  